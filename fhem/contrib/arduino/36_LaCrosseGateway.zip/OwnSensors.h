#ifndef _OWNSENSORS_h
#define _OWNSENSORS_h

#include "WSBase.h"
#include "BMP180.h"
#include "BME280.h"
#include "DHTxx.h"
#include "LM75.h"

class OwnSensors : public WSBase {
public: 
  OwnSensors();
  bool TryInitialize();
  bool HasBMP180();
  bool HasBME280();
  bool HasDHT22();
  bool HasLM75();
  String GetFhemDataString();
  void SetAltitudeAboveSeaLevel(int altitude);

protected:
  bool m_hasBMP180;
  bool m_hasBME280;
  bool m_hasDHT22;
  bool m_hasLM75;
  
  BMP180 m_bmp;
  BME280 m_bme;
  DHTxx m_dht;
  LM75 m_lm75;

  
  unsigned long m_lastMeasurement;
};


#endif

