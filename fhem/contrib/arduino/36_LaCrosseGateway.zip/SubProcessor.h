#ifndef _SUBPROCESSOR_H
#define _SUBPROCESSOR_H

#include "Arduino.h"
#include "ESP8266WiFi.h"
#include "WiFiClient.h"
#include "ESP8266WebServer.h"
#include "ESP8266mDNS.h"
#include "SC16IS750.h"
#include "FS.h"

class SubProcessor {
public:
  SubProcessor();
  void Begin(ESP8266WebServer *server, SC16IS750 *expander, byte dtrPort);
  void Reset();
  void Handle();
  bool HasReceivedData();
  String GetReceivedData();
  typedef void LogItemCallbackType(String, bool);
  void SetLogItemCallback(LogItemCallbackType callback);

private:
  ESP8266WebServer *m_server;
  SC16IS750 *m_expander;
  String m_log;
  LogItemCallbackType *m_logItemCallback;
  byte m_dtrPort;
  File m_uploadFile;
  word m_currentPage;
  bool m_flashing;
  unsigned long m_originalBaudRate;
  String m_receivedData;
  String m_dispatchData;
  void Log(String text, bool newLine = true);
  void FlashFile(File *file);
  void BeginFlash();
  void SendFile(File *file);
  void FinishFlash();
  void SendBytes(byte count, ...);
  void SendBytes(byte count, byte *data);
  void Receive();
  void SendPage(byte packet[128], byte size);
};


#endif

