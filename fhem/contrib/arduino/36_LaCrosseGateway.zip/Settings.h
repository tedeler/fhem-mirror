#ifndef _SETTINGS_h
#define _SETTINGS_h

#include "Arduino.h"
#include "HashMap.h"

#define EEPROM_SIZE 1024

class Settings {
public:
  Settings();

  void Read();
  void Write();
  void Dump();

  String Get(String key, String defaultValue);
  int GetInt(String key, int defaultValue);

  void Add(String key, String value);
  void Remove(String key);


private:
  HashMap<String, String, 25> m_data;
  static bool m_debug;
};





#endif

