#include "OwnSensors.h"

OwnSensors::OwnSensors() {
  m_hasBMP180 = false;
  m_hasBME280 = false;
  m_hasDHT22 = false;
  m_hasLM75 = false;
  m_lastMeasurement = 0;
}

bool OwnSensors::TryInitialize() {
  SetAltitudeAboveSeaLevel(0);
  
  m_hasBME280 = m_bme.TryInitialize(0x76);
  m_hasBMP180 = m_bmp.TryInitialize();
  ////m_hasDHT22 = m_dht.TryInitialize(9);
  m_hasLM75 = m_lm75.TryInitialize(0x4F);

  return m_hasBMP180 || m_hasBME280 || m_hasDHT22 || m_hasLM75;
}

bool OwnSensors::HasBMP180() {
  return m_hasBMP180;
}

bool OwnSensors::HasBME280() {
  return m_hasBME280;
}

bool OwnSensors::HasDHT22() {
  return m_hasDHT22;
}

bool OwnSensors::HasLM75() {
  return m_hasLM75;
}

void OwnSensors::SetAltitudeAboveSeaLevel(int altitude) {
  m_bmp.SetAltitudeAboveSeaLevel(altitude);
  m_bme.SetAltitudeAboveSeaLevel(altitude);
}


String OwnSensors::GetFhemDataString(){
  String fhemString = "";

  if (millis() >= m_lastMeasurement + 10000) {

    struct Frame frame;
    frame.ID = 0;
    frame.CRC = 0;
    frame.LowBatteryFlag = false;
    frame.NewBatteryFlag = false;
    frame.ErrorFlag = false;
    frame.IsValid = false;
    frame.HasHumidity = false;
    frame.HasPressure = false;
    frame.HasRain = false;
    frame.HasTemperature = false;
    frame.HasWindDirection = false;
    frame.HasWindGust = false;
    frame.HasWindSpeed = false;

    if (m_hasBME280) {
      frame.HasPressure = true;
      frame.HasTemperature = true;
      frame.HasHumidity = true;
      frame.Temperature = m_bme.GetTemperature();
      frame.Pressure = m_bme.GetPressure();
      frame.Humidity = m_bme.GetHumidity();
      frame.IsValid = true;
    }

    if (!m_hasBME280 && m_hasBMP180) {
      frame.HasPressure = true;
      frame.HasTemperature = true;
      frame.Temperature = m_bmp.GetTemperature();
      frame.Pressure = m_bmp.GetPressure();
      frame.IsValid = true;
    }

    if (!m_hasBME280 && m_hasDHT22) {
      if (m_dht.TryMeasure()) {
        frame.HasTemperature = true;
        frame.HasHumidity = true;
        frame.Humidity = m_dht.GetHumidity();
        frame.Temperature = m_dht.GetTemperature();
        frame.IsValid = true;
      }
    }
    
    if (!m_hasBME280 && !m_hasBMP180 && !m_hasDHT22 && m_hasLM75) {
      frame.HasTemperature = true;
      frame.Temperature = m_lm75.GetTemperature();
      frame.IsValid = true;
    }

    if (frame.IsValid) {
      fhemString = BuildFhemDataString(&frame, 4);
    }

    m_lastMeasurement = millis();
  }

  return fhemString;
}



 