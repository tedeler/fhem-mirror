#include "SubProcessor.h"
//#define LOGMORE 1

SubProcessor::SubProcessor() {
  m_logItemCallback = nullptr;
}

void SubProcessor::Begin(ESP8266WebServer *server, SC16IS750 *expander, byte dtrPort) {
  m_server = server;
  m_expander = expander;
  m_log = "";
  m_flashing = false;

  m_dtrPort = dtrPort;
  m_receivedData = "";
  m_dispatchData = "";

  m_expander->PinMode(m_dtrPort, OUTPUT);
  m_expander->DigitalWrite(m_dtrPort, HIGH);

  // Upload 
  m_server->on("/ota/addon.hex", HTTP_POST, [this]() {
    m_server->sendHeader("Connection", "close");
    m_server->sendHeader("Access-Control-Allow-Origin", "*");

    Dir dir = SPIFFS.openDir("/");
    while (dir.next()) {
      String fileName = dir.fileName();
      if (fileName == "/addon.hex") {
        Log("File: " + fileName + " Size: " + String(dir.fileSize()));
        File f = dir.openFile("r");
        FlashFile(&f);
        f.close();
      }
    }

    m_server->send(200, "text/plain", m_log);
    m_flashing = false;
  }, [this]() {
    HTTPUpload &upload = m_server->upload();
    if (upload.status == UPLOAD_FILE_START){
      m_flashing = true;
      m_log = "";
      Log("Start receiving '", false);
      Log(upload.filename, false);
      Log("'");
      ////Serial.println("==== STOP ====");
      ////m_server->stop();
      String path = "/" + upload.filename;
      SPIFFS.begin();
      m_uploadFile = SPIFFS.open(path, "w");
    }
    else if (upload.status == UPLOAD_FILE_WRITE){
      if (m_uploadFile) {
        m_uploadFile.write(upload.buf, upload.currentSize);
      }
    }
    else if (upload.status == UPLOAD_FILE_END){
      if (m_uploadFile) {
        m_uploadFile.close();
      }
      ////m_server->begin();
      ////Serial.println("==== BEGIN ====");
    }
    yield();
  });

}

void SubProcessor::SetLogItemCallback(LogItemCallbackType callback) {
  m_logItemCallback = callback;
}

void SubProcessor::Log(String text, bool newLine) {
  if (m_flashing) {
    m_log += text + (newLine ? "\n" : "");
    if (m_logItemCallback) {
      m_logItemCallback(text, newLine);
    }
  }
}

void SubProcessor::Reset() {
  m_expander->DigitalWrite(m_dtrPort, LOW);
  delay(50);
  m_expander->DigitalWrite(m_dtrPort, HIGH);
}

void SubProcessor::SendBytes(byte count, ...) {
  byte data[count];
  va_list parameters;
  va_start(parameters, count);
  for (int i = 0; i < count; i++) {
    byte bt = (byte)va_arg(parameters, int);
    data[i] = bt;
  }
  SendBytes(count, data);
  va_end(parameters);
}

void SubProcessor::SendBytes(byte count, byte *data) {
  #ifdef LOGMORE
    Log("-> ", false);
  #endif
  for (int i = 0; i < count; i++) {
    ////byte bt = data[i];
    m_expander->Write(data[i]);
    ////String ch = " ";
    ////if (data[i] >= 0x30 && data[i] <= 0x7A) {
      ////ch = String((char)bt);
    ////}
    ////Log("[" + ch + " " + String(bt, 16) + "] ", false);
  }
  #ifdef LOGMORE
    Log("");
  #endif
}

void SubProcessor::Receive() {
  byte count = m_expander->Available();
  #ifdef LOGMORE
    Log("<- ", false);
  #endif
  for (int i = 0; i < count; i++) {
    byte bt = m_expander->Read();
    #ifdef LOGMORE
      Log("[ " + String(bt, 16) + "] ", false);
    #endif
  }
  #ifdef LOGMORE
    Log("");
  #endif 
}

void SubProcessor::BeginFlash() {
  m_originalBaudRate = m_expander->GetBaudrate();
  m_expander->SetBaudrate(57600);

  while (m_expander->Available()) {
    m_expander->Read();
  }

  // Send sync
  Log("Sending sync");
  SendBytes(2, 0x30, 0x20);
  delay(250);
  Receive();

  // Enter program mode 
  Log("Enter program mode");
  SendBytes(2, 'P', 0x20);
  delay(50);
  Receive();
}

void SubProcessor::SendPage(byte packet[128], byte size) {
  word dummy = m_currentPage * 64;
  SendBytes(4, 'U', (byte)(dummy & 0xFF), (byte)(dummy >> 8), 0x20);
  delay(10);
  Receive();

  byte data[256];
  byte pos = 0;
  data[pos++] = 'd';
  data[pos++] = 0;
  data[pos++] = size;
  data[pos++] = 'F';

  for (int i = 0; i < size; i++) {
    data[pos++] = packet[i];
  }

  data[pos++] = 0x20;
  SendBytes(pos, data);
  delay(10);
  Receive();


  m_currentPage++;
}

void SubProcessor::SendFile(File *file){
  String line;
  bool goOn = true;        

  byte packet[128];
  byte packetSize = 0;
  m_currentPage = 0;
  word totalSize = 0;

  byte dummy = 0;
  unsigned long handledBytes = 0;
  while (goOn) {
    line = file->readStringUntil(10);
    if (line.length() > 0) {
      if (line.length() > 7 && line.substring(7, 9) == "00") {
        byte len = (byte)strtol(line.substring(1, 3).c_str(), NULL, HEX);
        String payloadString = line.substring(9, 9 + (len + 1) * 2);

        for (byte i = 0; i < len * 2; i += 2) {
          String oneByteString = payloadString.substring(i, i + 2);
          byte oneByte = (byte)strtol(oneByteString.c_str(), NULL, HEX);

          packet[packetSize] = oneByte;
          packetSize++;
          totalSize++;
          if (packetSize == 128) {
            SendPage(packet, packetSize);
            packetSize = 0;
          }
        }
      }
    }
    else {
      if (packetSize > 0) {
        SendPage(packet, packetSize);
      }
      goOn = false;
    }
  }
  Log("Binary size is:", false);
  Log(String(totalSize));
}

void SubProcessor::FinishFlash() {
  Log("Leave Program Mode");
  SendBytes(2, 'Q', 0x20);
  delay(50);
  Receive();

  m_expander->SetBaudrate(m_originalBaudRate);
}

void SubProcessor::FlashFile(File *file) {
  Log("Starting flash");
  Reset();
  delay(200);
  BeginFlash();
  SendFile(file);
  FinishFlash();
  Log("Flash finished");
}

void SubProcessor::Handle(){
  byte count = m_expander->Available();
  if (m_dispatchData.length() == 0 && count > 0) {
    for (byte i = 0; i < count; i++) {
      byte bt = m_expander->Read();
      if (bt != 13 && bt != 10) {
        m_receivedData += String((char)bt);
      }

      if (bt == 13) {
        m_dispatchData = m_receivedData;
        m_receivedData = "";
      }
    }
  }
}

bool SubProcessor::HasReceivedData() {
  return m_dispatchData.length() > 0;
}

String SubProcessor::GetReceivedData() {
  String result = m_dispatchData;
  m_dispatchData = "";
  return result;
}