#ifndef ESP8266TOOLS_H
#define ESP8266TOOLS_H

#include "Arduino.h"

class ESP8266Tools {
public:
  ESP8266Tools(byte ledPin);
  void Blink(byte ct, bool force=false);
  void EnableLED(bool enable);
  void SwitchLed(boolean on, bool force=false);

private:
  byte m_ledPin;
  bool m_ledEnabled;

};


#endif

