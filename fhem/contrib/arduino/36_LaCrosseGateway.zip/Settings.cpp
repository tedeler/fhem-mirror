#include "Settings.h"
#include "EEPROM.h"

Settings::Settings() {
}

void Settings::Read() {
  m_data.Clear();

  EEPROM.begin(EEPROM_SIZE);
  String rawData;
  for (int i = 0; i < EEPROM_SIZE; i++) {
    rawData += (char)EEPROM.read(i);
  }
  EEPROM.end();
  
  if(rawData[0] == 1) {
    String key = "";
    String value = "";
    bool keyDone = false;
    bool valueDone = false;
    for (uint i=1; i < rawData.length(); i++) {
      if (!keyDone) {
        if (rawData[i] != 2) {
          key += (char)rawData[i];
        }
        else {
          keyDone = true;
          continue;
        }
      }
      
      if (keyDone && !valueDone) {
        if (rawData[i] != 1) {
          value += (char)rawData[i];
        }
        else {
          valueDone = true;
        }
      }
    
      if (keyDone && valueDone) {
        keyDone = false;
        valueDone = false;
        if(key.length() > 0 && value.length() > 0) {
          m_data.Put(key, value);
        }
        key = "";
        value = "";
      }
      
    }
  }

}

void Settings::Write() {
  String rawData;
  
  rawData += (char)1;
  for(uint i=0; i < m_data.Size(); i++) {
    rawData += m_data.GetKeyAt(i);
    rawData += (char)2;
    rawData += m_data.GetValueAt(i);
    rawData += (char)1;
  }
 
  while (rawData.length() < EEPROM_SIZE) {
    rawData += (char)0;
  }
  EEPROM.begin(EEPROM_SIZE);
  for (int i = 0; i < EEPROM_SIZE; i++) {
    EEPROM.write(i, rawData[i]);
  }
  EEPROM.end();
  
}

void Settings::Dump() {
  m_data.Dump();
}

String Settings::Get(String key, String defaultValue) {
  return m_data.Get(key, defaultValue);
}

int Settings::GetInt(String key, int defaultValue) {
  return atoi(Get(key, String(defaultValue)).c_str());
}

void Settings::Add(String key, String value) {
  if (m_data.ContainsKey(key)) {
    m_data.Remove(key);
  }
  return m_data.Put(key, value);
}

void Settings::Remove(String key) {
  return m_data.Remove(key);
}